#include <stdlib.h>
#include <iostream>
#include <stdio.h>
#include <unistd.h>
#include <math.h>
#include "zestet1_network.h"

#include "./API.c"

#define READ_BUFFER_SIZE_MAX 1000000
#define WRITE_BLOCKSIZE_MAX  1000000

int main(int argc, char *argv[])
{

  SOCKET SocketHandle;
  fd_set FD_Reading;
  fd_set FD_Writing;

  uint64_t TxBytes;
  uint64_t RxBytes;

  uint64_t BytesReceived;
  char RxBuffer[READ_BUFFER_SIZE_MAX];
  uint64_t BytesWritten;
  uint8_t TxBuffer[256];
  uint64_t TxBufferBytesUsed;
  uint32_t Counter_Value = 0;

  uint8_t TestSignal[4500000];
  uint64_t TestSignalLength = 0;
  uint64_t TestSignalLength_COPY = 0;
  uint64_t TestSignalPos = 0;
  uint64_t TestSignalWritten = 0;
  uint64_t Counter = 0;

  uint64_t BytesReadTotal = 0;

  ssize_t BytesWrittenToNetwork = 0;
  ssize_t BytesReadFromNetwork = 0;
  ssize_t BytesReadFromNetwork_2 = 0;

  ssize_t BytesWrittenLog = 0;
  ssize_t BytesReadLog = 0;

  ssize_t BALANCE = 0;

  ssize_t TotalBytesWrittenToNetwork = 0;
  ssize_t TotalBytesReadFromNetwork = 0;

  int FIFO_FULL_STATUS = 0;

  long ReturnValueForSelect = 0;

  struct timeval TimeOut_Read;
  TimeOut_Read.tv_sec = 1;
  TimeOut_Read.tv_usec = 0;
  int FirstRun = 1;
  int Read10MByteBlockDone = 0;

  FILE * READLOG = NULL;
  FILE * WRITELOG = NULL;

  READLOG = fopen("./read.txt","w");
  WRITELOG = fopen("./write.txt","w");



  // Test Signal
  TestSignalLength = 0;
  for (Counter_Value = 0; Counter_Value < 65535; Counter_Value ++)
  {

    API_GetPackage(&TxBufferBytesUsed, &TestSignal[TestSignalLength], 1, 0, 0,
      (uint16_t)(65535.0*(sin(2.0 * 3.1415 * (double) Counter_Value / 65535.0)+1.0)/2.0), Counter_Value , 3, 4,
      5, 6, 7, 8,
      9, 10, 11, 12,
      13, 14, 15, 16, 3,
      3, 0, 3, 0);
      TestSignalLength += TxBufferBytesUsed;

    }
    API_GetPackage(&TxBufferBytesUsed, &TestSignal[TestSignalLength], 1, 0, 0,
      (uint16_t)(65535.0*(sin(2.0 * 3.1415 *(double) 65535.0 / 65535.0)+1.0)/2.0), 65535, 3, 4,
      5, 6, 7, 8,
      9, 10, 11, 12,
      13, 14, 15, 16, 3,
      3, 0, 3, 0);
      TestSignalLength += TxBufferBytesUsed;
      printf("Testsignal Length: %u\n",TestSignalLength);
      for (Counter = 0; Counter < READ_BUFFER_SIZE_MAX; Counter ++)
      {
        RxBuffer[Counter] = 0;
      }

      if( MakeNetworkConnection(&SocketHandle, "192.168.1.101", 0x5002, &FD_Reading , &FD_Writing) == -1)
      {
        std::cout << "Network connection couldn't be established.\n";
        return 0;
      }

      // We send this stuff for signaling that both FPGAs have the same language.
      // This has to be done only once after a reset.
      API_GetEntrainmentString(&TxBufferBytesUsed, TxBuffer);
      BytesWrittenToNetwork = send(SocketHandle,(char *) TxBuffer,TxBufferBytesUsed,0);
      if (BytesWrittenToNetwork > 0){
        TotalBytesWrittenToNetwork += BytesWrittenToNetwork;
        //std::cout << BytesWrittenToNetwork << "\n";
      }
      //
      //   FirstRun = 1;
      //
      TestSignalLength_COPY = TestSignalLength;
      TestSignalPos = 0;
      for (Counter = 0; Counter < 100; Counter ++) {
        while(TestSignalLength > 0) {

          BytesWrittenToNetwork = 0;
          //if (TotalBytesWrittenToNetwork < 2000000) {
            if (TestSignalLength > WRITE_BLOCKSIZE_MAX){
              BytesWrittenToNetwork = send(SocketHandle,(char *) &TestSignal[TestSignalPos],WRITE_BLOCKSIZE_MAX,0);
            }
            else {
              BytesWrittenToNetwork = send(SocketHandle,(char *) &TestSignal[TestSignalPos],TestSignalLength,0);
            }
          //}
          usleep(10000);

          if (BytesWrittenToNetwork > 0){
            BytesWrittenLog = fwrite((char *) &TestSignal[TestSignalPos],1,BytesWrittenToNetwork,WRITELOG);
            if (BytesWrittenLog != BytesWrittenToNetwork) {
                std::cout << "XXXX\n";
            }

            TestSignalPos += BytesWrittenToNetwork;

            TestSignalLength -= BytesWrittenToNetwork;
          }
          else {
            BytesWrittenToNetwork = 0;
          }
          TotalBytesWrittenToNetwork += BytesWrittenToNetwork;

          //
          //       // We are not allowed to flood the network device
          //       if (TotalBytesWrittenToNetwork >= 10000000) {
          //         printf("+");
          //
          //         // First 10MB (we want to kepp the network device filled
          //         // in the range of 10-20MByte, absolute max is 32MByte)
          //         if (FirstRun == 1) {
          //           FirstRun = 0;
          //         }
          //         // All the other 10MB Blocks
          //         else {
          //           Read10MByteBlockDone = 0;
          //           do {
          BytesReadFromNetwork = recv(SocketHandle,(char *)RxBuffer,READ_BUFFER_SIZE_MAX,MSG_DONTWAIT);
          if (BytesReadFromNetwork > 0) {
            BytesReadLog = fwrite((char *)RxBuffer,1,BytesReadFromNetwork,READLOG);
            if (BytesReadLog != BytesReadFromNetwork) {
              std::cout << "YYYY\n";
            }
          }
          else {
            BytesReadFromNetwork = 0;
          }

          BytesReadFromNetwork_2 += BytesReadFromNetwork;

          TotalBytesWrittenToNetwork -= (ssize_t)(BytesReadFromNetwork_2/2);
          BytesReadFromNetwork_2 -=  ((ssize_t)(BytesReadFromNetwork_2/2))*2;
          std::cout << Counter << " " << TotalBytesWrittenToNetwork << "\n";

          //
          //               if ((RxBuffer[1]&1) == 1){
          //                 Read10MByteBlockDone = 1;
          //               }
          //               if (((RxBuffer[1]>>1)&1) == 1){
          //                 printf("Temperatur problem detected!\n");
          //               }
          //               if (((RxBuffer[1]>>2)&1) == 1){
          //                 printf("Entrainment error!\n");
          //               }
          //               if (((RxBuffer[1]>>3)&1) == 1){
          //                 printf("Packet broken!\n");
          //               }
          //             }
          //           } while(Read10MByteBlockDone == 0);
          //         }
          //         TotalBytesWrittenToNetwork -= 10000000;
          //         printf(".\n");
          //       }
        }

        TestSignalLength = TestSignalLength_COPY;
        TestSignalPos = 0;
      }


      if (CloseNetworkConnection(&SocketHandle) == -1)
      {
        std::cout << "Network connection couldn't be closed.\n";
        return 0;
      }

      fclose(READLOG);
      fclose(WRITELOG);

      return 0;
    };
