// -------------------------
// ITP - Uni Bremen
// 29.07.2011 
// David Rotermund 
// -------------------------

// Note: This files makes heavy use of the Orange Tree Files

#include <stdio.h>
#include <iostream>
#include <fstream>
#include <string.h>

#include "bitfile_tools.h"


long BitFile::ConvertTwoByteIntoLong(std::streamsize StreamPosition)
{
    long Value = 0;

    // Is there data to convert?     
    if ((RAWImage == NULL) || (RAWImage_Length < 2))
    {
	std::cout << "BitFile Class - Rawdata is not available for conversion into long.\n";
	return -1;
    }

    // Is this a legal request?     
    if (StreamPosition + 1 + 1  > RAWImage_Length)
    {
	std::cout << "BitFile Class - During conversion into long, StreamPosition was too large .\n";
	return -1;
    }

    Value = RAWImage[StreamPosition]*256 + RAWImage[(StreamPosition+1)];
    
    return Value;    
};

long BitFile::ConvertFourByteIntoLong(std::streamsize StreamPosition)
{
    long Value = 0;

    // Is there data to convert?     
    if ((RAWImage == NULL) || (RAWImage_Length < 2))
    {
	std::cout << "BitFile Class - Rawdata is not available for conversion into long.\n";
	return -1;
    }

    // Is this a legal request?     
    if (StreamPosition + 3 + 1  > RAWImage_Length)
    {
	std::cout << "BitFile Class - During conversion into long, StreamPosition was too large .\n";
	return -1;
    }

    Value = RAWImage[StreamPosition]*256*256*256 + RAWImage[(StreamPosition+1)] *256 * 256  + RAWImage[(StreamPosition+2)] *256 + RAWImage[(StreamPosition+3)] ;
    
    return Value;    
};

int BitFile::AnalyseBitFile(void)
{
    long Value = 0;

    long Counter = 0;
    std::streamsize ActualPosition = 0;

    ImageIsOkay = false;
        
    // Is there data to convert?     
    if ((RAWImage == NULL) || (RAWImage_Length < 1))
    {
	std::cout << "BitFile Class - AnalyseBitFile - Rawdata is not available for conversion into long.\n";
	return -1;
    }

    // Segment 1 => File Header 
    Length_Header = ConvertTwoByteIntoLong(0);
    if (Length_Header == -1)
    {
	std::cout << "BitFile Class - AnalyseBitFile - Getting Length_Segment1 failed.\n";
	return -1;
    }

    // Check the length 
    if (Length_Header != 9)
    {
	std::cout << "BitFile Class - AnalyseBitFile - Header has wrong size.\n";
	return -1;
    }
    
    // Check the header 
    // Header should be 0F F0 from [2] - [9]
    for (Counter = 2; Counter < 10; Counter += 2)
    {
	if (RAWImage[Counter] != 0x0F)
	{
	    std::cout << "BitFile Class - AnalyseBitFile - Header is wrong.\n";
	    return -1;
	}
	if (RAWImage[Counter+1] != 0xF0)
	{
	    std::cout << "BitFile Class - AnalyseBitFile - Header is wrong.\n";
	    return -1;
	}
    }
    // Header should be 00 @ 10 and 11
    if (RAWImage[10] != 0x00)
    {
        std::cout << "BitFile Class - AnalyseBitFile - Header is wrong.\n";
        return -1;
    }
    if (RAWImage[11] != 0x00)
    {
        std::cout << "BitFile Class - AnalyseBitFile - Header is wrong.\n";
        return -1;
    }

    if (RAWImage[12] != 0x01)
    {
        std::cout << "BitFile Class - AnalyseBitFile - Header is wrong.\n";
        return -1;
    }

    // Is there a second segment ? 
    if (RAWImage[13] != 0x61)
    {
        std::cout << "BitFile Class - AnalyseBitFile - Second segment is defect.\n";
        return -1;
    }

    ActualPosition = 14;
    
    // Segment 2 => DesignName
    Length_DesignName = ConvertTwoByteIntoLong(ActualPosition);
    
    if (Length_DesignName == -1)
    {
        std::cout << "BitFile Class - AnalyseBitFile - Designname is missing.\n";
        return -1;
    }
    
    ActualPosition = 16;

    // Extract the design name 
    if (DesignName != NULL)
    {
	delete DesignName;
    }    
    DesignName = NULL;
    
    DesignName = new char[Length_DesignName+1];
    
    if (DesignName == NULL)
    {
        std::cout << "BitFile Class - AnalyseBitFile - Designname array couldn't be created.\n";
        return -1;
    }

    DesignName[Length_DesignName] = 0;   
    
    
    if (RAWImage_Length < ActualPosition+Length_DesignName-1)
    {
        std::cout << "BitFile Class - AnalyseBitFile - Designname extraction failed.\n";
        return -1;
    }
    memcpy(DesignName,RAWImage + ActualPosition,Length_DesignName);    
    ActualPosition = ActualPosition + Length_DesignName;    

    // Is there a third segment ? 
    if (RAWImage[ActualPosition] != 0x62)
    {
        std::cout << "BitFile Class - AnalyseBitFile - Third segment is defect.\n";
        return -1;
    }
    ActualPosition +=  1;
    
    // Segment 3 => PartName
    Length_PartName = ConvertTwoByteIntoLong(ActualPosition);
    
    if (Length_PartName == -1)
    {
        std::cout << "BitFile Class - AnalyseBitFile - Partname is missing.\n";
        return -1;
    }
    ActualPosition +=  2;
    
    // Extract the part name 
    if (PartName != NULL)
    {
	delete PartName;
    }    
    PartName = NULL;
    
    PartName = new char[Length_PartName+1];
    
    if (PartName == NULL)
    {
        std::cout << "BitFile Class - AnalyseBitFile - PartName array couldn't be created.\n";
        return -1;
    }

    PartName[Length_PartName] = 0;   
    
    
    if (RAWImage_Length < ActualPosition+Length_PartName-1)
    {
        std::cout << "BitFile Class - AnalyseBitFile - Partname extraction failed.\n";
        return -1;
    }
    memcpy(PartName,RAWImage + ActualPosition,Length_PartName);    
    ActualPosition = ActualPosition + Length_PartName;    

    // Is there a fourth segment ? 
    if (RAWImage[ActualPosition] != 0x63)
    {
        std::cout << "BitFile Class - AnalyseBitFile - Fourth segment is defect.\n";
        return -1;
    }
    ActualPosition +=  1;

    // Segment 4 => Date
    Length_Date = ConvertTwoByteIntoLong(ActualPosition);
    
    if (Length_Date == -1)
    {
        std::cout << "BitFile Class - AnalyseBitFile - Date is missing.\n";
        return -1;
    }
    ActualPosition +=  2;
    
    // Extract the date
    if (Date != NULL)
    {
	delete Date;
    }    
    Date = NULL;
    
    Date = new char[Length_Date+1];

    if (Date == NULL)
    {
        std::cout << "BitFile Class - AnalyseBitFile - Date array couldn't be created.\n";
        return -1;
    }

    Date[Length_Date] = 0;   
    
    if (RAWImage_Length < ActualPosition+Length_Date-1)
    {
        std::cout << "BitFile Class - AnalyseBitFile - Date extraction failed.\n";
        return -1;
    }
    memcpy(Date,RAWImage + ActualPosition,Length_Date);    
    ActualPosition = ActualPosition + Length_Date;    

    // Is there a fifth segment ? 
    if (RAWImage[ActualPosition] != 0x64)
    {
        std::cout << "BitFile Class - AnalyseBitFile - Fifth segment is defect.\n";
        return -1;
    }
    ActualPosition +=  1;

    // Segment 5 => Time
    Length_Time = ConvertTwoByteIntoLong(ActualPosition);
    
    if (Length_Time == -1)
    {
        std::cout << "BitFile Class - AnalyseBitFile - Time is missing.\n";
        return -1;
    }
    ActualPosition +=  2;
    
    // Extract the time
    if (Time != NULL)
    {
	delete Time;
    }    
    Time = NULL;
    
    Time = new char[Length_Time+1];

    if (Time == NULL)
    {
        std::cout << "BitFile Class - AnalyseBitFile - Time array couldn't be created.\n";
        return -1;
    }
    
    Time[Length_Time] = 0;   
    
    if (RAWImage_Length < ActualPosition+Length_Time-1)
    {
        std::cout << "BitFile Class - AnalyseBitFile - Time extraction failed.\n";
        return -1;
    }
    memcpy(Time,RAWImage + ActualPosition,Length_Time);    
    ActualPosition = ActualPosition + Length_Time;    

    // Is there a six segment ? 
    if (RAWImage[ActualPosition] != 0x65)
    {
        std::cout << "BitFile Class - AnalyseBitFile - Sixth segment is defect.\n";
        return -1;
    }
    ActualPosition +=  1;

    // Segment 6 => BitImage
    Length_BitImage = ConvertFourByteIntoLong(ActualPosition);
    
    if (Length_BitImage == -1)
    {
        std::cout << "BitFile Class - AnalyseBitFile - BitImage is missing.\n";
        return -1;
    }
    ActualPosition +=  4;

    // Extract the BitImage
    if (BitImage != NULL)
    {
	delete BitImage;
    }    
    BitImage = NULL;
    
    BitImage = new unsigned char[Length_BitImage];
    
    if (BitImage == NULL)
    {
        std::cout << "BitFile Class - AnalyseBitFile - BitImage array couldn't be created.\n";
        return -1;
    }
    
    if (RAWImage_Length < ActualPosition+Length_BitImage-1)
    {
        std::cout << "BitFile Class - AnalyseBitFile - BitImage extraction failed.\n";
        return -1;
    }
    memcpy(BitImage,RAWImage + ActualPosition,Length_BitImage);    
    ActualPosition = ActualPosition + Length_BitImage;    

    Value += Length_Header+3+1;
    Value += Length_DesignName+3;
    Value += Length_PartName+3;
    Value += Length_Date+3;
    Value += Length_Time+3;
    Value += Length_BitImage+1+4;

    // Compare expected and real length information 
    if (Value != RAWImage_Length)
    {
        std::cout << "BitFile Class - AnalyseBitFile - There is a difference between the real and the expected length.\n";
	return -1;
    }

    // Check the FPGA Type
    KnownFPGAType = false;
    if (strstr(PartName,"3s1400a") == NULL)
    {
	std::cout << "BitFile Class - AnalyseBitFile - Unknown FPGA typ.\n";
	return -1;    
    }
    
    ImageIsOkay = true;

    RAWImage_Length = 0;
    delete RAWImage;
    RAWImage = NULL;

    return 0;
}

int BitFile::ShowFileInfo(void)
{
    // Was there data to convert?     
    if (ImageIsOkay == true)
    {
	std::cout << "Filename : " << TheFilename << "\n";
	std::cout << "\n";
    
	std::cout << "Name of the design : " << DesignName << "\n";    
	std::cout << "Partname : " << PartName << "\n";    
	std::cout << "Date : " << Date << "\n";    
	std::cout << "Time : " << Time << "\n";    
	std::cout << "\n";

	std::cout << "Structure is okay!\n";
    }
    else
    {
	std::cout << "Structure is defect or nothing was imported!!!\n";
    }
    
    return 0;
}

int BitFile::OpenFile(char * Filename)
{
    std::fstream BitFileStream(Filename,std::ios_base::in | std::ios_base::binary);        
    std::streamsize FileLength;
    
    if (BitFileStream.is_open() != true)
    {
	std::cout << "BitFile Class - Couldn't open bitfile \n";
	return -1;
    }

    // Get the file size
    BitFileStream.seekg(0,std::ios::end);
    FileLength = BitFileStream.tellg();	
    BitFileStream.seekg(0,std::ios::beg);

    // Delte an old bit file
    if (RAWImage != NULL)
    {
        delete RAWImage;
    }
    RAWImage = NULL;
    RAWImage_Length = 0;

    // Create a new array for storing the image 	
    RAWImage = new unsigned char[FileLength];	
    RAWImage_Length = FileLength;

    // Check if we have a vaild array	
    if (RAWImage == NULL)
    {
        std::cout << "BitFile Class - Couldn't get the necessary memory for the RAW Image\n";
        RAWImage_Length = 0;
        return -1;
    }

    // Read the file	
    BitFileStream.read((char *)RAWImage, RAWImage_Length);

    // Check if the whole file was read	
    if (BitFileStream.gcount() != RAWImage_Length)
    {
        std::cout << "BitFile Class - Couldn't read the whole file.\n";
        if (RAWImage != NULL)
        {
    	    delete RAWImage;
        }
        RAWImage = NULL;
        RAWImage_Length = 0;
        return -1;
    }

    // CLose the file	
    BitFileStream.close();    
    

    if (TheFilename != NULL)
    {
	delete TheFilename;
    }
    TheFilename = NULL;
    
    TheFilename = new char[5000];
    
    if (TheFilename == NULL)
    {
	std::cout << "BitFile Class - Couldn't copy the filename.\n";	
	return -1;    
    }
    
    strcpy(TheFilename,Filename);
    
    AnalyseBitFile();
     
    return 0;
}

// Constructor 
BitFile::BitFile()
{
    TheFilename = NULL;
    ImageIsOkay = false;    
    RAWImage = NULL;
    RAWImage_Length = 0;

    Length_Header = -1;    

    Length_DesignName = -1;
    DesignName = NULL;
    Length_PartName = -1;
    PartName = NULL;
    Length_Date = -1;
    Date = NULL;			
    Length_Time = -1;
    Time = NULL;			
    Length_BitImage = -1;
    BitImage = NULL;
    KnownFPGAType = false;
    
    return ;
}; 

// Destructor 
BitFile::~BitFile()
{

    if (TheFilename != NULL)
    {
	delete  TheFilename;
    }
    TheFilename = NULL;
    ImageIsOkay = false;    
    if (RAWImage != NULL)
    {
	delete RAWImage;
    }
    RAWImage = NULL;
    RAWImage_Length = 0;
    
    Length_Header = -1;    

    Length_DesignName = -1;
    
    if (DesignName != NULL)
    {
	delete DesignName;
    }
    DesignName = NULL;
    
    Length_PartName = -1;
    
    if (PartName != NULL)
    {
	delete PartName;
    }
    PartName = NULL;
    
    Length_Date = -1;
    if (Date != NULL)
    {
	delete Date;
    }
    Date = NULL;			

    Length_Time = -1;
    if (Time != NULL)
    {
	delete Time;
    }
    Time = NULL;			
    
    Length_BitImage = -1;
    
    if (BitImage != NULL)
    {
	delete BitImage;
    }
    BitImage = NULL;

    KnownFPGAType = false;

    return ;
}; 

bool BitFile::IsImageOkay(void)
{
    return ImageIsOkay;
};
int BitFile::GetImage(unsigned char * Address)
{
    if (Address == NULL)
    {
	std::cout << "BitFile class - GetImage - Adress is NULL\n";
	return -1;
    }

    if (ImageIsOkay == false)
    {
	std::cout << "BitFile class - GetImage - There is no image to get.\n";
	return -1;
    }
    memcpy(Address, BitImage,Length_BitImage);    
    
    return 0;
};

long BitFile::GetImageLength(void)
{
    return Length_BitImage;
};

int BitFile::GetImage_ZestET1Revered(unsigned char * Address)
{
    long Counter = 0;
    if (Address == NULL)
    {
	std::cout << "BitFile class - GetImage_ZestET1Revered - Adress is NULL\n";
	return -1;
    }

    if (ImageIsOkay == false)
    {
	std::cout << "BitFile class - GetImage_ZestET1Revered - There is no image to get.\n";
	return -1;
    }

    // Reverse the byte order... 
    for (Counter = 0; Counter < Length_BitImage; Counter += 4)
    {
	Address[Counter+0] =  BitImage[Counter+3];    
	Address[Counter+1] =  BitImage[Counter+2];    
	Address[Counter+2] =  BitImage[Counter+1];    
	Address[Counter+3] =  BitImage[Counter+0];    
    }
    
    return 0;
};

/*
int main()
{
    BitFile * MyBitFile = NULL;

    // Create the object 
    MyBitFile = new BitFile();
    MyBitFile->OpenFile((char *)"Example2.bit");
    
    MyBitFile->ShowFileInfo();
    
    // Clean up    
    if (MyBitFile != NULL)
    {
	delete MyBitFile;
	MyBitFile = NULL;
    }
    

    return 0;
}
*/

