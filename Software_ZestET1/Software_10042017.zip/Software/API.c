#include <stdlib.h>
#include <stdint.h>

// We can use this function to calculate the value for the Switch control
// 0 = off, 1 = on
// In the test system A = Channel 00, B = Channel 01
uint16_t API_GetSwitchValue(uint8_t Channel00, uint8_t Channel01, uint8_t Channel02, uint8_t Channel03,
                            uint8_t Channel04, uint8_t Channel05, uint8_t Channel06, uint8_t Channel07,
                            uint8_t Channel08, uint8_t Channel09, uint8_t Channel10, uint8_t Channel11,
                            uint8_t Channel12, uint8_t Channel13, uint8_t Channel14, uint8_t Channel15){
  uint16_t Temp = 0;
  Temp += (Channel00 & 1) * 1;
  Temp += (Channel01 & 1) * 2;
  Temp += (Channel02 & 1) * 4;
  Temp += (Channel03 & 1) * 8;
  Temp += (Channel04 & 1) * 16;
  Temp += (Channel05 & 1) * 32;
  Temp += (Channel06 & 1) * 64;
  Temp += (Channel07 & 1) * 128;
  Temp += (Channel08 & 1) * 256;
  Temp += (Channel09 & 1) * 512;
  Temp += (Channel10 & 1) * 1024;
  Temp += (Channel11 & 1) * 2048;
  Temp += (Channel12 & 1) * 4096;
  Temp += (Channel13 & 1) * 8192;
  Temp += (Channel14 & 1) * 16384;
  Temp += (Channel15 & 1) * 32768;
  return Temp;
};

// The firmware needs this for seeing that the connection is okay.
// Use this only ONCE.
int API_GetEntrainmentString(uint64_t * BufferLength, uint8_t * Buffer){

  if (BufferLength == NULL) {
    return -1;
  }

  if (Buffer == NULL) {
    return -1;
  }

  BufferLength[0] = 12;

  Buffer[0] = 170;
  Buffer[1] = 202;
  Buffer[2] = 213;
  Buffer[3] = 74;
  Buffer[4] = 169;
  Buffer[5] = 156;
  Buffer[6] = 227;
  Buffer[7] = 175;
  Buffer[8] = 42;
  Buffer[9] = 0;
  Buffer[10] = 0;
  Buffer[11] = 0;
  return 0;
};

// Address:
// 0: Wildcard (everything)
// 1: The address of the 16 channel block


// Mode:
// 0 = Normal Mode
// 1 = Set Gain (01)
// 2 = Set offset (10)

// TimeSetting:
// How long should I hold one value after it was set to the DAC?
// 40bit value of clock cycles, where it is measures against a 25MHz clock

// Values for the DAC's 16 channels (16bit) 0= max negative voltage, 65535 = max positive voltage

// Switches:
// CS: Enables(1) or disables (0) the current source
// A: Output current source
// B: Direction to recording system
// C: Connection to between the Electrodes and the rest
// D: Gnd connection after B


int API_GetPackage(uint64_t * BufferLength, uint8_t * Buffer, uint8_t Address, uint8_t Mode, uint64_t TimerSetting,
                    uint16_t Value00, uint16_t Value01, uint16_t Value02, uint16_t Value03,
                    uint16_t Value04, uint16_t Value05, uint16_t Value06, uint16_t Value07,
                    uint16_t Value08, uint16_t Value09, uint16_t Value10, uint16_t Value11,
                    uint16_t Value12, uint16_t Value13, uint16_t Value14, uint16_t Value15, uint16_t CS_ENABLE,
                    uint16_t SwitchA, uint16_t SwitchB, uint16_t SwitchC, uint16_t SwitchD) {

  if (BufferLength == NULL) {
    return -1;
  }

  if (Buffer == NULL) {
    return -1;
  }

  *BufferLength = 56;

  Buffer[0] = 255;
  Buffer[1] = 170;
  Buffer[2] = Address;

  // Byte 01 - 04
  if (Mode == 1) {
    Buffer[3] = 85;
    Buffer[4] = 85;
    Buffer[5] = 85;
    Buffer[6] = 85;
  }
  else if (Mode == 2) {
    Buffer[3] = 170;
    Buffer[4] = 170;
    Buffer[5] = 170;
    Buffer[6] = 170;
  }
  else {
    Buffer[3] = 255;
    Buffer[4] = 255;
    Buffer[5] = 255;
    Buffer[6] = 255;
  }
  // Byte 05 - 09
  Buffer[7] = (uint8_t)(TimerSetting & 255);
  TimerSetting = TimerSetting >> 8;
  Buffer[8] = (uint8_t)(TimerSetting & 255);
  TimerSetting = TimerSetting >> 8;
  Buffer[9] = (uint8_t)(TimerSetting & 255);
  TimerSetting = TimerSetting >> 8;
  Buffer[10] = (uint8_t)(TimerSetting & 255);
  TimerSetting = TimerSetting >> 8;
  Buffer[11] = (uint8_t)(TimerSetting & 255);

  // Value00
  Buffer[12] = (uint8_t)(Value00 & 255);
  Value00 = Value00 >> 8;
  Buffer[13] = (uint8_t)(Value00 & 255);
  // Value01
  Buffer[14] = (uint8_t)(Value01 & 255);
  Value01 = Value01 >> 8;
  Buffer[15] = (uint8_t)(Value01 & 255);
  // Value02
  Buffer[16] = (uint8_t)(Value02 & 255);
  Value02 = Value02 >> 8;
  Buffer[17] = (uint8_t)(Value02 & 255);
  // Value03
  Buffer[18] = (uint8_t)(Value03 & 255);
  Value03 = Value03 >> 8;
  Buffer[19] = (uint8_t)(Value03 & 255);
  // Value04
  Buffer[20] = (uint8_t)(Value04 & 255);
  Value04 = Value04 >> 8;
  Buffer[21] = (uint8_t)(Value04 & 255);
  // Value05
  Buffer[22] = (uint8_t)(Value05 & 255);
  Value05 = Value05 >> 8;
  Buffer[23] = (uint8_t)(Value05 & 255);
  // Value06
  Buffer[24] = (uint8_t)(Value06 & 255);
  Value06 = Value06 >> 8;
  Buffer[25] = (uint8_t)(Value06 & 255);
  // Value07
  Buffer[26] = (uint8_t)(Value07 & 255);
  Value07 = Value07 >> 8;
  Buffer[27] = (uint8_t)(Value07 & 255);
  // Value08
  Buffer[28] = (uint8_t)(Value08 & 255);
  Value08 = Value08 >> 8;
  Buffer[29] = (uint8_t)(Value08 & 255);
  // Value09
  Buffer[30] = (uint8_t)(Value09 & 255);
  Value09 = Value09 >> 8;
  Buffer[31] = (uint8_t)(Value09 & 255);
  // Value10
  Buffer[32] = (uint8_t)(Value10 & 255);
  Value10 = Value10 >> 8;
  Buffer[33] = (uint8_t)(Value10 & 255);
  // Value11
  Buffer[34] = (uint8_t)(Value11 & 255);
  Value11 = Value11 >> 8;
  Buffer[35] = (uint8_t)(Value11 & 255);
  // Value12
  Buffer[36] = (uint8_t)(Value12 & 255);
  Value12 = Value12 >> 8;
  Buffer[37] = (uint8_t)(Value12 & 255);
  // Value13
  Buffer[38] = (uint8_t)(Value13 & 255);
  Value13 = Value13 >> 8;
  Buffer[39] = (uint8_t)(Value13 & 255);
  // Value14
  Buffer[40] = (uint8_t)(Value14 & 255);
  Value14 = Value14 >> 8;
  Buffer[41] = (uint8_t)(Value14 & 255);
  // Value15
  Buffer[42] = (uint8_t)(Value15 & 255);
  Value15 = Value15 >> 8;
  Buffer[43] = (uint8_t)(Value15 & 255);

  // CS_ENABLE
  Buffer[44] = (uint8_t)(CS_ENABLE & 255);
  CS_ENABLE = CS_ENABLE >> 8;
  Buffer[45] = (uint8_t)(CS_ENABLE & 255);

  // Switch A
  Buffer[46] = (uint8_t)(SwitchA & 255);
  SwitchA = SwitchA >> 8;
  Buffer[47] = (uint8_t)(SwitchA & 255);

  // Switch B
  Buffer[48] = (uint8_t)(SwitchB & 255);
  SwitchB = SwitchB >> 8;
  Buffer[49] = (uint8_t)(SwitchB & 255);

  // Switch C
  Buffer[50] = (uint8_t)(SwitchC & 255);
  SwitchC = SwitchC >> 8;
  Buffer[51] = (uint8_t)(SwitchC & 255);

  // Switch D
  Buffer[52] = (uint8_t)(SwitchD & 255);
  SwitchD = SwitchD >> 8;
  Buffer[53] = (uint8_t)(SwitchD & 255);

  // Reserve
  Buffer[54] = 0;
  Buffer[55] = 0;

  return 0;
};
